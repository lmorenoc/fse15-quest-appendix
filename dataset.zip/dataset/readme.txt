CHANGE REQUEST DATA

Each folder corresponds to a different project and contains 3 files:

1. *_Mapping.txt - Each line of this file corresponds to the path (identifier) of a class in the project.

2. *_Corpus.txt - Each line of this file corresponds to the *preprocessed* text of a method in the project. An empty line (which can be disregarded) separates the methods. This file is related to the *_Mapping.txt file, i.e., line 1 in the Corpus is the text corresponding to the path in the line 1 in the Mapping, line 3 in the Corpus is the text corresponding to the path in the line 2 in the Mapping, etc.

3. *_Queries.txt - Each entry in this file corresponds to a bug report.  The entries are separated by an empty line. Each entry consists of:
Line 1: change request id
Line 2: preprocessed text of the change request (title / description / title + description)
Line 3: number of classes modified to solve the change request
Line 4 (and next lines until an empty line): paths of the methods modified to solve the change request.
